###### 一、测试过程说明

1、该项目是对pupil_detect的训练结果进行测试

2、pupil_detect代码封装到libretina.so中

3、由test_examples路径下的pupil_detect_test进行测试。

4、测试数据为瞳孔图片，对多张图片进行标记，查看最终标记结果。

5、测试时，pupil_detect项目中_pupil_detect.cpp的p_threshold、r_threshold、o_threshold均为0.5

###### 二、测试结果

1、总共对445张图片进行测试
2、识别出433张
3、程序识别出的瞳孔中心点与人工标记中心点误差为：3.73（x坐标误差+ y坐标误差的平均值）
4、图片识别率为：433 / 455 * 100% =  97.3%

