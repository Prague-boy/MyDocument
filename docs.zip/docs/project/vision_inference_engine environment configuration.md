### 关于vision_inference_engine 的环境配置说

###### 一、对于刚安装的linux操作系统，该项目运行所需环境与vision_inference_engine项目一致，具体配置如下： 

1、安装cmake

作用：用于对项目进行编译及管理

命令：sudo apt-get install cmake，检测是否安装成功  cmake –version

2、安装git

作用：方便从其他地方获取项目，

安装命令： sudo apt-get install git

3、安装qmake（可选）

作用：与cmake作用一致，用于对项目进行编译（注：后期会不再使用，以cmake为主）

安装命令：sudo  apt  install qt5-qmake

4.对MNN进行配置：

（1）下载MNN源代码，将代码放到指定文件路径下，一般建议/home/usrName（用户）/ProjectName（项目名称） 

下载路径：https://hub.fastgit.org/alibaba/MNN.git

（2）对MNN源代码进行编译，并安装，具体步骤如下：

​	1）git clone https://hub.fastgit.org/alibaba/MNN.git      #使用git将MNN文件拷贝到制定路径，

​    2）cd MNN                                                              #切换到项目中，MNN为文件名，根据所下载项目名进行调整

​	3）git checkout 1.2.3                                             #选中该版本

​	4）./schema/generate.sh                                     #生成项目

​	5）mkdir build                                                        #创建build目录，存储cmake产生的文件

​	6）cd build/                                                             #切入build目录

​	7）cmake .. -DMNN_BUILD_CONVERTER=true -DCMAKE_INSTALL_PREFIX=./install  

​     #使用cmake编译指定编译路径为build下的install目录，如果没有install，系统会自动创建，也可自己指定路径

​	8）make -j4                                                              #生成

​	9）make install                                                        #安装                      



5.安装protobuf，具体步骤如下：

1）git clone https://hub.fastgit.org/protocolbuffers/protobuf.git

2）cd protobuf

3）git tag                                                                    #查看版本状态

4）git checkout v3.6.1                                              #选择v3.6.1版本

5）./configure CXXFLAGS=-fPIC --prefix=/home/ryanchen/3rdparty/Protobuf-3.6.1   

最终安装路径为/home/ryanchen/3rdparty/Protobuf-3.6.1，可根据自己的要求设置，但需要和Qmake文件规定路径一致，否则VIE项目无法找到关联文件

6）make -j8

7）make install



6.安装opencv，具体步骤如下：

1）git clone https://github.com.cnpmjs.org/opencv/opencv.git

2）cd opencv

3）git tag

4）git checkout 4.5.3

5）cmake -DCMAKE_INSTALL_PREFIX=/home/ryanchen/3rdparty/Opencv-4.5.3 ..

6）make -j

7）make install



7.安装OpenBLAS，具体步骤如下：

1）git clone https://github.com.cnpmjs.org/xianyi/OpenBLAS.git

2）cd OpenBLAS

3）git tag

4）git checkout v0.3.18

5）make NO_LAPACKE=1 NO_LAPACK=1 NOFORTRAN=1

6）make PREFIX=/home/ryanchen/3rdparty/OpenBLAS-0.3.18 install





8.对vision_inference_engine 进行编译，具体步骤

1）git clone http://172.16.0.2/HPIA/vision_inference_engine.git

2）cd vision_inference_engine/

3）cd Qmake/

4）qmake x86_64_build_sdk.pro      #.pro文件中相关依赖库路径需根据上述环境搭建时的路径进行调整

5）make -j8

6）make install

###### 遇到的问题：

1、运行程序时提示：cannot open shared object file: No such file or directory

解决方法：

（1）终端输入 sudo gedit /etc/ld.so.conf

（2）添加确实库文件目录：/home/xxxxx，保存推出

（3）终端运行 sudo ldconfig，使配置生效。
