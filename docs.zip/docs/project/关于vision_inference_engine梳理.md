### VIE 项目梳理 

1、主要包含文件：3rdparty/Authentication

​                                 3rdparty/caffe

​                                 ExtractFeature

注：3rdparty中其它项暂未进行包含编译。(maby i didn't get it)





2、调用关系

VIE项目生成libVIE.so，接口文件为extractfeature.h文件，由VRP项目中facula_detect_16a调用

