###### 一、测试过程说明

1、该项目是对pupil_detect_16a的训练结果进行测试

2、pupil_detect_16a代码封装到libretina.so中

3、由test_examples路径下的pupil_detect_16a_test进行测试。

4、测试数据为瞳孔图片，对多张图片进行标记，查看最终标记结果。

5、测试时，pupil_detect_16a项目中_pupil_detect.cpp的p_threshold、r_threshold、o_threshold均为0.5

###### 二、测试结果

1、总共对2847张图片进行测试
2、识别出2595张
3、程序识别出的瞳孔中心点与人工标记中心点误差为：1.37（x坐标误差+ y坐标误差的平均值）
4、图片识别率为：2595 / 2847 * 100% =  91.115%


