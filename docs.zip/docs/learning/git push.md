git add -A

git commit -m "xxx"

git config --global  usr.email "xx@xx.com"

git push origin xxxx(分支名)



删除本地分支

git branch -d xxx